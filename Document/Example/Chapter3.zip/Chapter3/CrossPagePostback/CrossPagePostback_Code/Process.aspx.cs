﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Process : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (this.PreviousPage.IsCrossPagePostBack)
        {
            TextBox txt1 = (TextBox)Page.PreviousPage.FindControl("txt_DonGia");
            TextBox txt2 = (TextBox)Page.PreviousPage.FindControl("txt_SoLuong");

            this.lbl_ThanhTien.Text = (int.Parse(txt1.Text) * int.Parse(txt2.Text)).ToString();
        }
    }
}