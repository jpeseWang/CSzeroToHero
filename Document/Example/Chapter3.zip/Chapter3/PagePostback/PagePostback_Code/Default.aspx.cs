﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_Tinh_Click(object sender, EventArgs e)
    {
        this.lbl_ThanhTien.Text = (int.Parse(this.txt_SoLuong.Text) * int.Parse(this.txt_DonGia.Text)).ToString();
    }
}