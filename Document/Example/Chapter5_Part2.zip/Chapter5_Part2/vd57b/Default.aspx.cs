using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Web.Configuration;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btn_Tinh_Click(object sender, EventArgs e)
    {
        SqlDataSource sqlDS = new SqlDataSource();
        SqlDS.ConnectionString = "Data Source=NGOCNHAN\\SQLEXPRESS;Initial Catalog=QLNS;"
            + "Persist Security Info=True;User ID=thuynt; Password = 123";

        sqlDS.SelectCommand = "SELECT DONGIA,SOLUONG FROM HANGHOA WHERE IDHANGHOA = @ID";
        sqlDS.SelectParameters.Add("ID",TypeCode.Int32,this.txt_MaHang.Text);

        DataView dv = (DataView)sqlDS.Select(DataSourceSelectArguments.Empty);
        if (dv.Count > 0)
        {
            int DonGia = Convert.ToInt32(dv.Table.Rows[0]["DONGIA"]);
            int SoLuong = Convert.ToInt32(dv.Table.Rows[0]["SOLUONG"]);
            int ThanhTien = DonGia * SoLuong;

            this.lbl_DonGia.Text = DonGia.ToString();
            this.lbl_SoLuong.Text = SoLuong.ToString();
            this.lbl_ThanhTien.Text = ThanhTien.ToString();
        }
        else
        {
            Response.Write("Khong tim thay ma hang nao!!!");
            this.lbl_DonGia.Text = "";
            this.lbl_SoLuong.Text = "";
        }
    }
}
